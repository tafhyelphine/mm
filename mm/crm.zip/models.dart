// lib/models.dart
import 'package:flutter/foundation.dart'; // Required for immutable annotation

@immutable // Good practice for model classes
class Order {
  final String id;
  final String product;
  String status; // Status can change, so not final
  final DateTime orderDate;

  Order({
    required this.id,
    required this.product,
    required this.status,
    required this.orderDate,
  });
}

@immutable // Good practice for model classes
class Customer {
  final String id;
  final String name;
  final String email;
  final String address;
  final String contact;
  final List<Order> orders; // List itself is final, but its contents (Orders) can change status

  Customer({
    required this.id,
    required this.name,
    required this.email,
    required this.address,
    required this.contact,
    required this.orders,
  });
}