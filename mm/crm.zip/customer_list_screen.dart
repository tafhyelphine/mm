// lib/customer_list_screen.dart
import 'package:flutter/material.dart';
import 'models.dart';
import 'customer_detail_screen.dart';
import 'register_customer_screen.dart';

class CustomerListScreen extends StatefulWidget {
  const CustomerListScreen({super.key});

  @override
  State<CustomerListScreen> createState() => _CustomerListScreenState();
}

class _CustomerListScreenState extends State<CustomerListScreen> {
  // --- Static Data ---
  // In a real app, this would come from a database.
  // We manage this list in the state so we can add new customers.
  final List<Customer> _customers = [
    Customer(
      id: 'C001',
      name: 'Alice Wonderland',
      email: 'alice@example.com',
      address: '123 Fantasy Lane',
      contact: '555-1234',
      orders: [
        Order(id: 'O1001', product: 'Magic Potion', status: 'Shipped', orderDate: DateTime(2024, 1, 10)),
        Order(id: 'O1002', product: 'Talking Flowers Seeds', status: 'Processing', orderDate: DateTime(2024, 1, 15)),
      ],
    ),
    Customer(
      id: 'C002',
      name: 'Bob The Builder',
      email: 'bob@example.com',
      address: '456 Construction St',
      contact: '555-5678',
      orders: [
        Order(id: 'O2001', product: 'Hammer', status: 'Delivered', orderDate: DateTime(2024, 1, 5)),
        Order(id: 'O2002', product: 'Wrench Set', status: 'Pending', orderDate: DateTime(2024, 1, 20)),
      ],
    ),
     Customer(
      id: 'C003',
      name: 'Charlie Chaplin',
      email: 'charlie@example.com',
      address: '789 Silent Film Ave',
      contact: '555-9012',
      orders: [], // No orders initially
    ),
  ];
  // --- End Static Data ---

  // Function to add a new customer to the list
  void _addCustomer(Customer customer) {
    setState(() {
      _customers.add(customer);
    });
  }

  // Function to navigate to registration screen
  void _navigateRegister() async {
    // We use await here in case the registration screen returns data,
    // but we handle adding via the callback (_addCustomer) passed to it.
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => RegisterCustomerScreen(
          onRegister: _addCustomer, // Pass the callback function
        ),
      ),
    );
    // No need to call setState here as _addCustomer already does it.
  }

  // Function to navigate to detail screen
  void _navigateDetails(Customer customer) {
     Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => CustomerDetailScreen(customer: customer),
      ),
    );
    // Note: Changes made in CustomerDetailScreen (like order status)
    // will modify the original objects in the _customers list.
    // A refresh isn't strictly needed here unless the list itself changes.
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Customers'),
        backgroundColor: Colors.blueGrey,
      ),
      body: ListView.builder(
        itemCount: _customers.length,
        itemBuilder: (context, index) {
          final customer = _customers[index];
          return ListTile(
            title: Text(customer.name),
            subtitle: Text(customer.email),
            leading: CircleAvatar( // Simple avatar
               backgroundColor: Colors.blueAccent,
               child: Text(customer.name.isNotEmpty ? customer.name[0] : '?', style: const TextStyle(color: Colors.white)),
            ),
            trailing: const Icon(Icons.arrow_forward_ios),
            onTap: () => _navigateDetails(customer),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _navigateRegister,
        tooltip: 'Register New Customer',
        child: const Icon(Icons.add),
      ),
    );
  }
}