// lib/main.dart
import 'package:flutter/material.dart';
import 'customer_list_screen.dart';

void main() {
  runApp(const SimpleCrmApp());
}

class SimpleCrmApp extends StatelessWidget {
  const SimpleCrmApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Simple CRM',
      theme: ThemeData(
        primarySwatch: Colors.blueGrey, // Use primary swatch for theme consistency
        visualDensity: VisualDensity.adaptivePlatformDensity,
          // Optional: Define app-wide text themes, button themes etc.
         appBarTheme: const AppBarTheme(
             backgroundColor: Colors.blueGrey,
             foregroundColor: Colors.white, // Title/icon color
          ),
           floatingActionButtonTheme: const FloatingActionButtonThemeData(
            backgroundColor: Colors.teal,
          ),
          chipTheme: ChipThemeData(
            padding: const EdgeInsets.all(2.0),
             labelStyle: const TextStyle(fontSize: 12, color: Colors.white), // Default chip text color
             secondaryLabelStyle: const TextStyle(fontSize: 12, color: Colors.white), // Used by default Chip widget
             brightness: Brightness.dark, // Ensures white text is visible on colored chips
          )
      ),
      home: const CustomerListScreen(), // Start with the customer list
      debugShowCheckedModeBanner: false, // Hide the debug banner
    );
  }
}