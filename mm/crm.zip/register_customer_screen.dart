// lib/register_customer_screen.dart
import 'package:flutter/material.dart';
import 'models.dart';

class RegisterCustomerScreen extends StatefulWidget {
  final Function(Customer) onRegister; // Callback function

  const RegisterCustomerScreen({required this.onRegister, super.key});

  @override
  State<RegisterCustomerScreen> createState() => _RegisterCustomerScreenState();
}

class _RegisterCustomerScreenState extends State<RegisterCustomerScreen> {
  final _formKey = GlobalKey<FormState>(); // Key for the form validation

  // Text editing controllers
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _addressController = TextEditingController();
  final _contactController = TextEditingController();

  @override
  void dispose() {
    // Clean up controllers when the widget is disposed
    _nameController.dispose();
    _emailController.dispose();
    _addressController.dispose();
    _contactController.dispose();
    super.dispose();
  }

  void _submitForm() {
    // Validate the form
    if (_formKey.currentState!.validate()) {
      // Create a new customer object
      // Simple ID generation (replace with better method in real app)
      final newId = 'C${DateTime.now().millisecondsSinceEpoch.toString().substring(8)}';

      final newCustomer = Customer(
        id: newId,
        name: _nameController.text,
        email: _emailController.text,
        address: _addressController.text,
        contact: _contactController.text,
        orders: [], // New customer starts with no orders
      );

      // Call the callback function passed from CustomerListScreen
      widget.onRegister(newCustomer);

      // Show success message
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('${newCustomer.name} registered successfully!')),
      );

      // Navigate back to the previous screen (CustomerListScreen)
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Register New Customer'),
         backgroundColor: Colors.blueGrey,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey, // Assign the key to the Form
          child: ListView( // Use ListView to prevent overflow on small screens
            children: [
              TextFormField(
                controller: _nameController,
                decoration: const InputDecoration(
                  labelText: 'Name',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.person),
                ),
                validator: (value) { // Simple validation
                  if (value == null || value.isEmpty) {
                    return 'Please enter a name';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 15),
              TextFormField(
                controller: _emailController,
                decoration: const InputDecoration(
                  labelText: 'Email',
                  border: OutlineInputBorder(),
                   prefixIcon: Icon(Icons.email),
                ),
                keyboardType: TextInputType.emailAddress,
                 validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter an email';
                  }
                  if (!value.contains('@')) { // Very basic email check
                     return 'Please enter a valid email';
                  }
                  return null;
                },
              ),
               const SizedBox(height: 15),
              TextFormField(
                controller: _addressController,
                decoration: const InputDecoration(
                  labelText: 'Address',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.home),
                ),
                 validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter an address';
                  }
                  return null;
                },
              ),
               const SizedBox(height: 15),
              TextFormField(
                controller: _contactController,
                decoration: const InputDecoration(
                  labelText: 'Contact Number',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.phone),
                ),
                keyboardType: TextInputType.phone,
                 validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter a contact number';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 30),
              ElevatedButton(
                onPressed: _submitForm,
                style: ElevatedButton.styleFrom(
                   padding: const EdgeInsets.symmetric(vertical: 15.0),
                   textStyle: const TextStyle(fontSize: 16),
                ),
                child: const Text('Register Customer'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}