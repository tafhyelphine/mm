// lib/customer_detail_screen.dart
import 'package:flutter/material.dart';
import 'package:intl/intl.dart'; // For date formatting (add intl package to pubspec.yaml)
import 'models.dart';

class CustomerDetailScreen extends StatefulWidget {
  final Customer customer;

  const CustomerDetailScreen({required this.customer, super.key});

  @override
  State<CustomerDetailScreen> createState() => _CustomerDetailScreenState();
}

class _CustomerDetailScreenState extends State<CustomerDetailScreen> {
  // List of possible statuses to cycle through
  final List<String> _orderStatuses = ['Pending', 'Processing', 'Shipped', 'Delivered', 'Cancelled'];

  // Function to update order status
  void _updateOrderStatus(Order order) {
    setState(() {
      // Find current status index
      int currentIndex = _orderStatuses.indexOf(order.status);
      // Get next status index (cycling back to start if needed)
      int nextIndex = (currentIndex + 1) % _orderStatuses.length;
      // Update the order's status directly
      // This works because 'order' is a reference to the object in the list
      order.status = _orderStatuses[nextIndex];
    });
     // Optional: Show a confirmation
     ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Order ${order.id} status updated to ${order.status}'),
          duration: const Duration(seconds: 1),
        ),
      );
  }

  @override
  Widget build(BuildContext context) {
    // Date formatter
    final DateFormat dateFormatter = DateFormat('yyyy-MM-dd');

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.customer.name),
         backgroundColor: Colors.blueGrey,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Customer Details Section
            Text('Customer Details', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 10),
            Card(
              elevation: 2,
              child: Padding(
                padding: const EdgeInsets.all(12.0),
                child: Column(
                   crossAxisAlignment: CrossAxisAlignment.start,
                   children: [
                     Text('ID: ${widget.customer.id}'),
                     Text('Email: ${widget.customer.email}'),
                     Text('Contact: ${widget.customer.contact}'),
                     Text('Address: ${widget.customer.address}'),
                   ]
                ),
              ),
            ),
            const SizedBox(height: 20),

            // Orders Section
            Text('Orders', style: Theme.of(context).textTheme.titleLarge),
            const Divider(),
            Expanded( // Use Expanded so the ListView takes available space
              child: widget.customer.orders.isEmpty
                  ? const Center(child: Text('No orders found for this customer.'))
                  : ListView.builder(
                      itemCount: widget.customer.orders.length,
                      itemBuilder: (context, index) {
                        final order = widget.customer.orders[index];
                        return Card(
                           margin: const EdgeInsets.symmetric(vertical: 4.0),
                           child: ListTile(
                              title: Text('Order ID: ${order.id} - ${order.product}'),
                              subtitle: Text('Date: ${dateFormatter.format(order.orderDate)}\nStatus: ${order.status}'),
                              isThreeLine: true, // Allows more space for subtitle
                              trailing: Chip( // Show status visually
                                label: Text(order.status),
                                backgroundColor: _getStatusColor(order.status),
                                labelStyle: const TextStyle(color: Colors.white),
                              ),
                              onTap: () => _updateOrderStatus(order), // Tap to change status
                            ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }

   // Helper function to get color based on status
   Color _getStatusColor(String status) {
     switch (status) {
       case 'Pending': return Colors.orange;
       case 'Processing': return Colors.blue;
       case 'Shipped': return Colors.green;
       case 'Delivered': return Colors.teal;
       case 'Cancelled': return Colors.red;
       default: return Colors.grey;
     }
   }
}